$(function () {
  const checkbox = $('#snb-more');
  const snbWrap = $('.snb-wrap');
  const arrow = $('.more-label .arrow');

  // 기본 숨김
  snbWrap.hide();

  // 더보기 버튼 클릭 시 토글
  checkbox.change(function () {
    if (this.checked) {
      snbWrap.show(); // 바로 보이게
      arrow.css('transform', 'rotate(-135deg)');
    } else {
      snbWrap.hide(); // 바로 숨김
      arrow.css('transform', 'rotate(45deg)');
    }
  });

  // 스크롤 시 즉시 닫기
  $(window).on("scroll", function () {
    if (checkbox.prop('checked')) {
      checkbox.prop("checked", false).trigger("change"); // 체크 해제 + 강제 트리거
    }
  });
});